import mlflow
from mlflow import MlflowClient

mlflow.set_tracking_uri("http://127.0.0.1:5000")

client = MlflowClient()

client.create_registered_model(
    name="Random_Forest-model",
    tags={
        "framework": "sklearn",
        "model": "RandomForest"
    },
    description="RandomForest has been Trained."
)

