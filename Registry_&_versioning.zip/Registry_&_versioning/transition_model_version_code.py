import mlflow
from mlflow import MlflowClient

# Set MLflow tracking URI
mlflow.set_tracking_uri("http://127.0.0.1:5000")

# Initialize MLflow client
client = MlflowClient()

# Transition model version to a different stage (e.g., Staging, Production, Archived)
client.transition_model_version_stage(
    name="Random_Forest-model",   # Registered model name
    version="1",                           # Version number
    stage="Production",                    # Target stage: "Staging", "Production", or "Archived"
    archive_existing_versions=True         # Archive any existing model in the target stage
)
