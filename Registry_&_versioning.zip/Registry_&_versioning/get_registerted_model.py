import mlflow
from mlflow import MlflowClient

# Set the MLflow tracking server URI
mlflow.set_tracking_uri("http://127.0.0.1:5000")

# Initialize the MLflow client
client = MlflowClient()

# Retrieve details of the registered model
model_info = client.get_registered_model(
    name="Random_Forest-model2"
)

# Display model details
print("Model Name      :", model_info.name)
print("Description     :", model_info.description)
print("Tags            :", model_info.tags)
