import mlflow
from mlflow import MlflowClient

# Set the MLflow tracking server URI
mlflow.set_tracking_uri("http://127.0.0.1:5000")

# Initialize the MLflow client
client = MlflowClient()

# Update the description of the registered model
client.update_registered_model(
    name="Random_Forest-model2",  # Registered model name
    description="""
        Testing Description for the registered model.
    """
)
