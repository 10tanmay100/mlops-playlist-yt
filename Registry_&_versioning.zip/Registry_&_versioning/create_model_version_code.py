import uuid
import joblib
import mlflow
import pandas as pd
import numpy as np
from mlflow import MlflowClient
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

# Set MLflow tracking URI
mlflow.set_tracking_uri("http://127.0.0.1:5000")
client = MlflowClient()

# Create a new MLflow run
run = client.create_run(
    experiment_id="0",
    tags={
        "team": "Data Science",
        "project": "MLflow",
        "version": "1.0",
        "testing": "Run"
    },
    run_name=f"my_run_{uuid.uuid4()}"
)

# Load dataset
url = "https://raw.githubusercontent.com/danwild/bike-share-prediction/master/Bike-Sharing-Dataset/day.csv"
data = pd.read_csv(url)

# Clean and prepare data
data = data.drop(columns=["instant", "dteday", "casual", "registered"])
target = "cnt"

# Split into train and test sets
train, test = train_test_split(data, test_size=0.2, random_state=42)
X_train, y_train = train.drop(columns=[target]), train[target]
X_test, y_test = test.drop(columns=[target]), test[target]

# Train Decision Tree Regressor
max_depth = 6
model = DecisionTreeRegressor(max_depth=max_depth, random_state=42)
model.fit(X_train, y_train)

# Make predictions
y_pred_train = model.predict(X_train)
y_pred_test = model.predict(X_test)

# Calculate evaluation metrics
mse = mean_squared_error(y_train, y_pred_train)
mae = mean_absolute_error(y_test, y_pred_test)
r2 = r2_score(y_test, y_pred_test)

# Save model
joblib.dump(model, "model.pkl")

# Log parameters and metrics
client.log_param(run.info.run_id, "max_depth", max_depth)
client.log_metric(run.info.run_id, "mse", mse)
client.log_metric(run.info.run_id, "mae", mae)
client.log_metric(run.info.run_id, "r2", r2)

# Save and log artifacts
data.to_csv("data.csv", index=False)
client.log_artifact(run.info.run_id, "data.csv")
client.log_artifact(run.info.run_id, "model.pkl")

# Register model version
mv=client.create_model_version(
    name="Random_Forest-model",
    source=f"runs:/{run.info.run_id}/sklearn_mlflow_pyfunc",
    tags={
        "framework": "sklearn",
        "model": "DecisionTreeRegressor",
    },
    description="A Decision Tree Regressor model trained on bike sharing data."
)

print(f"Name: {mv.name}")
print(f"Version: {mv.version}")
print(f"Description: {mv.description}")
print(f"Status: {mv.status}")
print(f"Stage: {mv.current_stage}")

# Set the run status to finished
client.set_terminated(run.info.run_id,status="FINISHED")

