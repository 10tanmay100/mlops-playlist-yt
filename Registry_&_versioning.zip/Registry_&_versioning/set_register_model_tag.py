import mlflow
from mlflow import MlflowClient

# Set the MLflow tracking server URI
mlflow.set_tracking_uri("http://127.0.0.1:5000")

# Initialize the MLflow client
client = MlflowClient()

# Set a custom tag on the registered model
client.set_registered_model_tag(
    name="Random_Forest-model2",  # Registered model name
    key="Model",                       # Tag key
    value="RF"            # Tag value
)
