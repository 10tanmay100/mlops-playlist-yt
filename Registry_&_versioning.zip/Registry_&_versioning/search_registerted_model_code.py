import mlflow
from mlflow import MlflowClient

# Set the MLflow tracking URI
mlflow.set_tracking_uri("http://127.0.0.1:5000")

# Initialize MLflow client
client = MlflowClient()

# Search for registered models with a specific tag
models = client.search_registered_models(
    filter_string="tags.Model = 'RF'",  # Filter by custom tag
    max_results=10                              # Sort by name ascending
)

# Print model name and associated tags
for model in models:
    print(f"Model Name: {model.name}, Tags: {model.tags}")
