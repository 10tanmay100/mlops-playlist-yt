import mlflow
from mlflow import MlflowClient

# Set the MLflow tracking URI
mlflow.set_tracking_uri("http://127.0.0.1:5000")

# Initialize the MLflow client
client = MlflowClient()

# Delete a specific version of the registered model
client.delete_model_version(
    name="Random_Forest-model",  # Registered model name
    version="2"                      # Model version to delete
)
