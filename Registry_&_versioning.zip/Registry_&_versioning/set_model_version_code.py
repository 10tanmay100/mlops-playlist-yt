import mlflow
from mlflow import MlflowClient

# Set the MLflow tracking server URI
mlflow.set_tracking_uri("http://127.0.0.1:5000")

# Initialize the MLflow client
client = MlflowClient()

# Set a tag on a specific version of a registered model
client.set_model_version_tag(
    name="Random_Forest-model",   # Registered model name
    version="1",                  # Model version to tag
    key="framework",             # Tag key
    value="sklearn-updated"      # Tag value
)
