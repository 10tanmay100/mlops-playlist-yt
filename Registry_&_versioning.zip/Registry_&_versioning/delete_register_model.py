import mlflow
from mlflow import MlflowClient

# Set the MLflow tracking URI
mlflow.set_tracking_uri("http://127.0.0.1:5000")

# Initialize the MLflow client
client = MlflowClient()

# Delete the registered model
client.delete_registered_model(
    name="Random_Forest-model2"  # Name of the model to be deleted
)
