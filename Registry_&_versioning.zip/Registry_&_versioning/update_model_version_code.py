import mlflow
from mlflow import MlflowClient

# Set MLflow tracking URI
mlflow.set_tracking_uri("http://127.0.0.1:5000")

# Initialize MLflow client
client = MlflowClient()

# Update the description of a specific model version
client.update_model_version(
    name="Random_Forest-model",        # Registered model name
    version="1",                           # Model version to update
    description="Updated dataset and description"  # New description
)
