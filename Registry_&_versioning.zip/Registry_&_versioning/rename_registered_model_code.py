import mlflow
from mlflow import MlflowClient

# Set the MLflow tracking server URI
mlflow.set_tracking_uri("http://127.0.0.1:5000")

# Initialize the MLflow client
client = MlflowClient()

# Rename an existing registered model
client.rename_registered_model(
    name="Random_Forest-model",       # Current model name
    new_name="Random_Forest-model4"  # New name for the model
)
