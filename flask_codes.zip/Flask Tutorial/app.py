from flask import Flask, request, render_template, jsonify


app=Flask(__name__)


@app.route("/")
def home():
    return render_template("housing.html")

#GET request example
@app.route("/status", methods=["GET"])
def status():
    return jsonify({"status": "OK"})

@app.route("/predict", methods=["POST"])
def predict():
    sqft = float(request.form.get("sqft"))
    bedroom = int(request.form.get("bedrooms"))
    age = int(request.form.get("age"))

    predict_price=(sqft*300)+(bedroom*5000)-(age*1000)

    return jsonify({"prediction": predict_price})

if __name__ == "__main__":
    app.run()




