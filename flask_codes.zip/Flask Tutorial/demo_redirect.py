from flask import Flask, render_template, redirect, url_for

## creating an instance of the Flask class
app = Flask(__name__)


# Route for Landing Page
@app.route("/")
def landing():
    return render_template("landing_page_ui.html")

@app.route("/login")
def login():
    return render_template("login_page_ui.html")

@app.route("/dashboard")
def dashboard():
    return render_template("dashboard_ui.html")

@app.route("/go-to-log")
def go_to_login():
    return redirect(url_for("login"))

@app.route("/go-to-landing")
def go_to_landing():
    return redirect(url_for("landing"))



if __name__ == "__main__":
    app.run(debug=True)