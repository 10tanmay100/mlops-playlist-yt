from flask import Flask, render_template

## creating an instance of the Flask class
app = Flask(__name__)

@app.route("/")
def home():
    return "Hello, World!"


@app.route("/greet/<name>/<age>")
def greet(name,age):
    return render_template("index.html", name=name,age=age) 


if __name__ == "__main__":
    app.run(debug=True)






