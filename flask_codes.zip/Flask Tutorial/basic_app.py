## importing flask
from flask import Flask

## creating an instance of the Flask class
app = Flask(__name__)

@app.route("/")
def home():
    return "Hello, World!"

@app.route("/next")
def nextt():
    return "Hello, next world!"


if __name__ == "__main__":
    app.run()