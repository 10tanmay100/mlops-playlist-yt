## importing flask
from flask import Flask

## creating an instance of the Flask class
app = Flask(__name__)



@app.route("/")
def home():
    return "Hello, World!"

@app.route("/next/<username>")
def nextt_user(username):
    return f"Hello, {username}!"

@app.route("/next/<int:post_id>")
def nextt_post(post_id):
    return f"Post ID: {post_id}"



if __name__ == "__main__":
    app.run(debug=True)