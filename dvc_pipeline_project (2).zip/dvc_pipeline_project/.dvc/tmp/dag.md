```mermaid
flowchart TD
	node1["data.dvc"]
	node2["data_ingestion"]
	node3["model_building"]
	node4["model_evaluation"]
	node1-->node2
	node2-->node3
	node3-->node4
```