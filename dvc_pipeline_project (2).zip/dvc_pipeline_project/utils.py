import yaml
import json

def load_params(params_path:str)->dict:
    with open(params_path, 'r') as file:
        params = yaml.safe_load(file)
    return params

def save_json(json_path:str,metrics:dict)->None:
    with open(json_path, 'w') as file:
        json.dump(metrics, file, indent=4)