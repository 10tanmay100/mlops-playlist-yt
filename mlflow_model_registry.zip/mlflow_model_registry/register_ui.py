import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, r2_score
import mlflow
import mlflow.sklearn
import os


# Load dataset from a URL
url = "https://raw.githubusercontent.com/rashida048/Datasets/refs/heads/master/StudentsPerformance.csv"
df = pd.read_csv(url)


# Handle missing values
df.dropna(inplace=True)

# Encode categorical variables
label_encoders = {}
for col in df.select_dtypes(include=['object']).columns:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])
    label_encoders[col] = le

# Select features and target
X = df.drop(columns=['math score'])  # Features
y = df['math score']  # Target variable

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Data preprocessing: Standardization
scaler = StandardScaler()


mlflow.set_tracking_uri("http://127.0.0.1:5000/")

print("Tracking uri",mlflow.get_tracking_uri())

#create experiment
exp=mlflow.set_experiment(experiment_name="exp3")


with mlflow.start_run(experiment_id=exp.experiment_id):
    n_estimators=57
    random_state=42
    params={
        'n_estimators': n_estimators,
        'random_state': random_state
    }

    mlflow.autolog(log_input_examples=True)
    model = RandomForestRegressor(n_estimators=params["n_estimators"], random_state=params["random_state"])
    model.fit(X_train, y_train)

    # Predictions
    y_pred = model.predict(X_test)

    # Evaluate model
    mae = mean_absolute_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)





