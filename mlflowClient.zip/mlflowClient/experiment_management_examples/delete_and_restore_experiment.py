import mlflow
from mlflow.tracking import MlflowClient


mlflow.set_tracking_uri("http://127.0.0.1:5000")
client = MlflowClient()

# delete_experiment()
# Soft deletes an experiment. It moves the experiment to the "deleted" state instead of permanently removing it.

# Parameters:
# experiment_id (str): The ID of the experiment.

experiment_id = "689679968372149318"
# client.delete_experiment(experiment_id)
# print(f"Experiment {experiment_id} deleted (soft delete).")

# restore_experiment()
# Restores a soft-deleted experiment.

# Parameters:
# experiment_id (str): The ID of the experiment.


client.restore_experiment(experiment_id)
print(f"Experiment {experiment_id} restored.")

