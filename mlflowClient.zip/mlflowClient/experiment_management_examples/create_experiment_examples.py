import mlflow
from mlflow.tracking import MlflowClient


mlflow.set_tracking_uri("http://127.0.0.1:5000")
client = MlflowClient()


# create_experiment()
# Creates a new experiment.

# Parameters:
# name (str): Name of the experiment (must be unique).

# artifact_location (Optional[str]): Location where artifacts will be stored. If None, MLflow will set a default location.


experiment_name = "testing123"
experiment_id = client.create_experiment(
    name=experiment_name,
    artifact_location=None,
    tags={"team": "Data Science", "project": "ML Model"}
)
print(f"Created Experiment: {experiment_name}, ID: {experiment_id}")


