import mlflow
from mlflow.tracking import MlflowClient


mlflow.set_tracking_uri("http://127.0.0.1:5000")
client = MlflowClient()

# set_experiment_tag()
# Adds or updates a tag (metadata) for an experiment.

# Parameters:
# experiment_id (str): The ID of the experiment.

# key (str): The tag key (e.g., "team").

# value (str): The tag value (e.g., "AI Team").

experiment_id="689679968372149318"
client.set_experiment_tag(experiment_id, "owner", "Tanmay")
print(f"Tag set for Experiment {experiment_id}")
