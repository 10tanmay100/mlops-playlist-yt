import mlflow
from mlflow.tracking import MlflowClient


mlflow.set_tracking_uri("http://127.0.0.1:5000")
client = MlflowClient()

# rename_experiment()
# Updates the name of an existing experiment.

# Parameters:
# experiment_id (str): The ID of the experiment.

# new_name (str): The new name to assign to the experiment.


new_experiment_name = "updated_testing"
client.rename_experiment("689679968372149318", new_experiment_name)
print(f"Experiment renamed to: {new_experiment_name}")
