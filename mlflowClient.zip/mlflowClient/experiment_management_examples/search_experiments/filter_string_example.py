import mlflow
from mlflow.tracking import MlflowClient

mlflow.set_tracking_uri("http://127.0.0.1:5000")
client = MlflowClient()



# filter_string Parameter (Filtering Based on Experiment Properties)
# This parameter applies filters similar to SQL WHERE conditions.

# Supported Operators:
# = → Equals

# != → Not equals

# LIKE → Partial match

# ILIKE → Case-insensitive partial match

# IN → Match against multiple values

# AND, OR → Combine conditions


# Fetch Experiments with a Specific Name
# experiments = client.search_experiments(filter_string="name = 'Experiment1'")
# for exp in experiments:
#     print(f"Experiment ID: {exp.experiment_id}, Name: {exp.name}")

# Fetch Experiments Containing 'testing' (Case-Sensitive)
# experiments = client.search_experiments(filter_string="name LIKE '%testing'")
# for exp in experiments:
#     print(f"Experiment ID: {exp.experiment_id}, Name: {exp.name}")


# # Fetch Experiments Containing 'test' (Case-Insensitive)
# experiments = client.search_experiments(filter_string="name ILIKE 'UPDATED%'")
# for exp in experiments:
#     print(f"Experiment ID: {exp.experiment_id}, Name: {exp.name}")


# Fetch Experiments with a Specific Tag
experiments = client.search_experiments(filter_string="tags.team = 'Data Science'")
for exp in experiments:
    print(f"Experiment ID: {exp.experiment_id}, Name: {exp.name}, Tags: {exp.tags}")







