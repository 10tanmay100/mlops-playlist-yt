import mlflow
from mlflow.tracking import MlflowClient

mlflow.set_tracking_uri("http://127.0.0.1:5000")
client = MlflowClient()



# This parameter filters experiments based on their status:

# 1 → ACTIVE_ONLY (default) → Returns only active experiments.

# 2 → DELETED_ONLY → Returns only deleted experiments.

# 3 → ALL → Returns both active and deleted experiments.


experiments = client.search_experiments(view_type=3)  # ACTIVE_ONLY
for exp in experiments:
    print(f"Experiment ID: {exp.experiment_id}")
    print(f"Name: {exp.name}")
    print(f"Artifact Location: {exp.artifact_location}")
    print(f"Lifecycle Stage: {exp.lifecycle_stage}")
    print(f"Tags: {exp.tags}")
    print("====================================================")


