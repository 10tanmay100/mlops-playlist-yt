import mlflow
from mlflow.tracking import MlflowClient

mlflow.set_tracking_uri("http://127.0.0.1:5000")
client = MlflowClient()



experiments = client.search_experiments(
    view_type=1,
    max_results=10,
    order_by=["name ASC"],
    filter_string="name LIKE '%test%' AND tags.team = 'AI'"
)
for exp in experiments:
    print(f"Experiment ID: {exp.experiment_id}, Name: {exp.name}, Tags: {exp.tags}")
