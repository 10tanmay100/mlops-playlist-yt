import mlflow
from mlflow.tracking import MlflowClient

mlflow.set_tracking_uri("http://127.0.0.1:5000")
client = MlflowClient()


# max_results parameter limits the number of experiments retrieved.
# order_by Parameter (Sorting Results)
# This parameter specifies the sorting order of experiments.

# Available Sorting Fields:
# "experiment_id ASC" → Sort by Experiment ID (ascending)

# "experiment_id DESC" → Sort by Experiment ID (descending)

# "name ASC" → Sort by Name (ascending)

# "name DESC" → Sort by Name (descending)

## ascending order example
# experiments = client.search_experiments(view_type=3,max_results=2, order_by=["name DESC"])
# for exp in experiments:
#     print(f"Experiment ID: {exp.experiment_id}, Name: {exp.name}")

print("====================================================")

## descending order example
experiments = client.search_experiments(view_type=3, order_by=["experiment_id DESC"])
for exp in experiments:
    print(f"Experiment ID: {exp.experiment_id}, Name: {exp.name}")
