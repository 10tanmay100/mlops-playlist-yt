import mlflow
from mlflow.tracking import MlflowClient


mlflow.set_tracking_uri("http://127.0.0.1:5000")
client = MlflowClient()


experiment = client.get_experiment("689679968372149318")
print(f"Experiment ID: {experiment.experiment_id}")
print(f"Name: {experiment.name}")
print(f"Artifact Location: {experiment.artifact_location}")
print(f"Lifecycle Stage: {experiment.lifecycle_stage}")
print(f"Tags: {experiment.tags}")
print("====================================================")





