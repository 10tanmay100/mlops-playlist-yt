import mlflow
from mlflow import MlflowClient
from mlflow.entities import ViewType


mlflow.set_tracking_uri("http://localhost:5000")

client=MlflowClient()

run=client.get_run("abc938789b9b44db8426b2c2b7217756")

artifacts=client.list_artifacts(run.info.run_id)
for artifact in artifacts:
    print(f"Artifact Path: {artifact.path}, File Size: {artifact.file_size}")