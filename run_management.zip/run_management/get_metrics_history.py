import mlflow
from mlflow import MlflowClient
from mlflow.entities import ViewType


mlflow.set_tracking_uri("http://localhost:5000")

client=MlflowClient()

run=client.get_run("c917157a48fc4820ac75558d62cd68c3")

metrics=client.get_metric_history(run.info.run_id, "mse")

for metric in metrics:
    print(f"Step: {metric.step}, Value: {metric.value}, Timestamp: {metric.timestamp}")