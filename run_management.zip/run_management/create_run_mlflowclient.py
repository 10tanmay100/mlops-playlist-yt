import mlflow
from mlflow import MlflowClient
from mlflow.entities import ViewType


mlflow.set_tracking_uri("http://localhost:5000")

client=MlflowClient()
experiment_name = "my_experiment1"
experiment_id = client.create_experiment(name=experiment_name,artifact_location=None,tags={"team":"Data Science","project":"MLflow"})

run=client.create_run(
    experiment_id=experiment_id,
    tags={
        "team":"Data Science",
        "project":"MLflow",
        "version":"1.0",
        "testing":"Run"
    },
    run_name="my_run"
)



print("Run ID:", run.info.run_id)
print("Run Name:", run.info.run_name)
print("Experiment ID:", run.info.experiment_id)
print("Experiment Name:", run.info.experiment_id)
print("Status:", run.info.status)
print("Lifecycle Stage:", run.info.lifecycle_stage)

