import mlflow
from mlflow import MlflowClient
from mlflow.entities import ViewType


mlflow.set_tracking_uri("http://localhost:5000")

client=MlflowClient()

runs=client.search_runs(
    experiment_ids=["756114439356322449"],
    run_view_type=ViewType.ACTIVE_ONLY,
    order_by=["start_time desc"],
)

for run in runs:
    print(f"Run ID: {run.info.run_id}")
    print(f"Run Name: {run.info.run_name}")
    print(f"Experiment ID: {run.info.experiment_id}")
    print(f"Experiment Name: {run.info.experiment_id}")
    print(f"Status: {run.info.status}")
    print(f"Lifecycle Stage: {run.info.lifecycle_stage}")
    print("===============================================")